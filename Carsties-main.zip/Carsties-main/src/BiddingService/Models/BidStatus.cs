﻿namespace BiddingService;

public enum BidStatus
{
    Accepted,
    AcceptedBelowReserve,
    TooLow,
    Finished
}
