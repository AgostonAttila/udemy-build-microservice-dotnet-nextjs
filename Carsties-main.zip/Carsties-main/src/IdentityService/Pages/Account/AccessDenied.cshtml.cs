using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IdentityService.Pages.Account;

public class AccessDeniedModel : PageModel
{
    public void OnGet()
    {
    }
}