﻿namespace Contracts;

public class AuctionDeleted
{
    public string Id { get; set; }
}
