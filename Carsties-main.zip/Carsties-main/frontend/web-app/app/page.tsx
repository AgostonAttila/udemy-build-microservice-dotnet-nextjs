import Listings from "./auctions/Listings";

export default function Home() {
  return (
    <div>
      <Listings />
    </div>
  )
}
