using Microsoft.AspNetCore.SignalR;

namespace NotificationService;

public class NotificationHub : Hub
{

}
